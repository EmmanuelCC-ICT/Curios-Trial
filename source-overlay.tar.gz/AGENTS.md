# Year 8 Learning World

Independent prototype derived from Career Empire's published source d3544e129682381d397417c08bed0242d5e58d88 on 6 November 2026.

- Work only in this separate project. Never change or publish the original Career Empire or its Blueprint.
- Keep discussion, plans, progress and visual evidence in docs/PROGRESS.md, updating this file at task close.
- Retain the existing environment, avatars, buildings and NPC visual assets. Curriculum, dialogue, quests, rewards and educational purpose belong to the Year 8 teachers.
- No original school accounts, student records, Supabase configuration, analytics or feedback services. Browser saves use a separate namespace.
- Static HTML/JavaScript. Keep paths relative so the project can live in its own ICT GitHub repository.
- Teacher configuration: world-config.json. Optional dialogue defaults to empty. Render teacher text as text, never executable HTML.
- Validate asset references and run node --test tests/*.test.mjs after substantive changes. Verify affected navigation, avatars and characters in a browser; distinguish source checks from actual visual acceptance.
- No new assets generated. Original asset ownership/licences still apply; provenance is not a licence transfer.

Status: local prototype and teacher editor implemented. Six focused tests and 65-module source checks pass; native campus/market/avatar/hall and teacher-preview/export checks passed. Basil clone/greeting added at user request; original remains independent. Destination EmmanuelCC-ICT/Curios-Trial supplied by user; explicit public publication approved. GitHub password confirmation/upload/deployment and final phone/live verification remain pending. See docs/PROGRESS.md.
